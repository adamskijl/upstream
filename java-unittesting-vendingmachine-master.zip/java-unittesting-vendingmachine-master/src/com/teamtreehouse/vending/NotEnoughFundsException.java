package com.teamtreehouse.vending;

public class NotEnoughFundsException extends Exception {
}
