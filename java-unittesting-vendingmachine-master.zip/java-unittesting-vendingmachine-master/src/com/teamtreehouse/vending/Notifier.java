package com.teamtreehouse.vending;

public interface Notifier {
    void onSale(Item item);
}
